//
//  FHInitRequest.h
//  FH
//
//  Created by Wei Li on 09/08/2012.
//  Copyright (c) 2012 FeedHenry. All rights reserved.
//

#import "FHAct.h"

/** Used internally to read app configurations fromt the server. */

@interface FHInitRequest : FHAct

@end
